#!/usr/bin/python
print "Content-type:text/html\r\n\r\n"
import cgi,cgitb
cgitb.enable()
import MySQLdb
import module
# Open database connection
db = MySQLdb.connect("localhost","biotoolz_ranjit","ranjitiisc","biotoolz_microbiome_explorer" )
# prepare a cursor object using cursor() method
cursor = db.cursor()


# Create instance of FieldStorage
form = cgi.FieldStorage()

# Get data from fields

data_run_group = form.getvalue('run_group')

sql = "Select * FROM projects where run_group = '" + data_run_group + "'"

cursor.execute(sql)
results = cursor.fetchall()

html_code='''

<html>

<head><title>microbiome_explorer</title>

<title>microbiome_explorer</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  

  <link href="/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/js/bootstrap.min.js"></script>
</head>
<body>'''
print html_code

module.print_func()



html_code='''
<div  class="container">

<div class="panel panel-default">
<div class="panel-heading">    
<b>EDIT PROJECTS</b>
</div>
      <div class="panel-body">  
      

      <form class="form-inline" action="save_projects.py" method="post">
'''
print html_code

for row in results:
 
  run_group = row[0]
  user_email = row[1]
  title = row[2]
  notes = row[3]
  links = row[4]

print 'Project Name:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'
print '<input type="text" name="run_group" style="width: 200px;"  class="form-control" value="' + run_group + '"><br><br>'
print 'Email:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'
print '<input type="text" name="user_email" style="width: 200px;"  class="form-control" value="' + user_email + '"><br><br>'

if title == None:
    title = ''
print 'Title:    &nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;<input type="text" class="form-control" name="title" rows=2 size="71" value="' + title + '"><br><br>'
print 'Notes: &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;<textarea class="form-control" name="notes" rows="6" cols="71">'
if notes == None:
    notes = ''

tmp_notes=notes.splitlines()
for items in tmp_notes:
    print str(items)  
print '</textarea><br><br>'

print 'Links: &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;<textarea class="form-control" name="links" rows="6" cols="71">'
if links == None:
    links = ''
tmp_links=links.splitlines()
for items in tmp_links:
    print str(items)
print '</textarea><br><br>'


html_code='''     
	    <button type="submit" class="btn btn-success">Save</button>
	  
        
      </form> 
      </div>
  
      
    
</div>
</div> 
</body>
</html>
'''
print html_code




