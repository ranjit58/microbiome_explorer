#!/usr/bin/python

import MySQLdb

# Open database connection
db = MySQLdb.connect("localhost","biotoolz_ranjit","ranjitiisc","biotoolz_microbiome_explorer" )

# prepare a cursor object using cursor() method
cursor = db.cursor()

# Create table as per requirement
sql = """CREATE TABLE samples (
         run_id VARCHAR(255),
         fwd_sample VARCHAR(255) NOT NULL PRIMARY KEY,
         rev_sample VARCHAR(255),
         sample_name VARCHAR(255) NOT NULL,
         run_group VARCHAR(255),  
         user_email VARCHAR(255) )"""

cursor.execute(sql)

# disconnect from server
db.close()

