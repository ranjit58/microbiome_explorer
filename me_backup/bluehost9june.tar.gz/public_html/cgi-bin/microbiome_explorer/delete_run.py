#!/usr/bin/python
print "Content-type:text/html\r\n\r\n"
import cgi, os
import cgitb;
cgitb.enable()
import MySQLdb
import module
# Open database connection
db = MySQLdb.connect("localhost","biotoolz_ranjit","ranjitiisc","biotoolz_microbiome_explorer" )
# prepare a cursor object using cursor() method
cursor = db.cursor()

# Create instance of FieldStorage 
form = cgi.FieldStorage() 

# Get data from fields
data_run = form.getvalue('run')
   
sql = "DELETE FROM runs WHERE run_id = '" + data_run + "';DELETE FROM samples where run_id = '" + data_run + "';"
cursor.execute(sql)
message = '<div class="container"><h4>Run deleted successfully</h4></div>'


html_code='''
Content-Type: text/html\n
<html>
<head>
<title>microbiome_explorer</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  

  <link href="/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/js/bootstrap.min.js"></script>
</head>
<body>
'''
print html_code
module.print_func()
print message
html_code='''

</body>
</html>
'''

print html_code
cursor.close()
db.commit()
 
# disconnect from server
db.close()

