#!/usr/bin/python
print "Content-type:text/html\r\n\r\n"
import cgi,cgitb
cgitb.enable()
import MySQLdb
import os, sys
import module


html_code='''

<html>

<head><title>microbiome_explorer</title>

<title>microbiome_explorer</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  

  <link href="/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/js/bootstrap.min.js"></script>
</head>
<body>
'''
print html_code
module.print_func()
html_code='''

<div class="container">

<div class="panel panel-default">
<div class="panel-heading">    
<b>Add data from run</b>
</div>
      <div class="panel-body">  


      <form enctype="multipart/form-data" class="form-inline" action="/~biotoolz/cgi-bin/microbiome_explorer/save_run.py" method="post">
      Sample Information&nbsp;<sup><span class="glyphicon glyphicon-asterisk" style="color:red;font-size: 8px"></span></sup>&nbsp;: &nbsp;&nbsp;&nbsp;&nbsp;<input type="file" class="form-control" name="filename">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;e.g. sample text file: <a href="../../microbiome_explorer/sample.txt">sample.txt</a><br><br>
      
      Run Number&nbsp;<sup><span class="glyphicon glyphicon-asterisk" style="color:red;font-size: 8px"></span></sup>&nbsp;:&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;<input type="text" class="form-control" name="run_id">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;e.g.&nbsp;M58&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
      &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
      Run_Name&nbsp;<sup><span class="glyphicon glyphicon-asterisk" style="color:red;font-size: 8px"></span></sup>&nbsp;: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" class="form-control" name="run_name">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;e.g.&nbsp;M58mar22<br><br>
      Run_Date&nbsp;<sup><span class="glyphicon glyphicon-asterisk" style="color:red;font-size: 8px"></span></sup>&nbsp;:    &nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;<input type="text" class="form-control" name="run_date">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;e.g.&nbsp;2015-03-22&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
      Run_Machine&nbsp;<sup><span class="glyphicon glyphicon-asterisk" style="color:red;font-size: 8px"></span></sup>&nbsp;: &nbsp;&nbsp;&nbsp;<input type="text" class="form-control" name="run_machine" value="MiSeq">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;e.g.&nbsp;MiSeq<br><br>
      Run_length&nbsp;<sup><span class="glyphicon glyphicon-asterisk" style="color:red;font-size: 8px"></span></sup>&nbsp;: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" class="form-control" name="run_read_length" value="2X251">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;e.g.&nbsp;2X251&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
      &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
      <br><br> 
     
      Run_Mapping: &nbsp;&nbsp;&nbsp;<input type="file" class="form-control" name="mapping_file">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;e.g. sample mapping file: <a href="../../microbiome_explorer/sample_mapping.xlsx">sample_mapping.xlsx</a><br><br>        
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;

	    <button type="submit" class="btn btn-success">Submit</button>
	    </div>
        
      </form> 
      </div>
  
      
    
</div>
</div>

    
  
  
   
</body>
</html>
'''
print html_code




