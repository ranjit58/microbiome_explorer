#!/usr/bin/python

import MySQLdb

# Open database connection
db = MySQLdb.connect("localhost","biotoolz_ranjit","ranjitiisc","biotoolz_microbiome_explorer" )

# prepare a cursor object using cursor() method
cursor = db.cursor()

# Prepare SQL query to INSERT a record into the database.
sql1 = "DELETE FROM samples"
  
 



cursor.execute(sql1)
db.commit()
# disconnect from server
db.close()
