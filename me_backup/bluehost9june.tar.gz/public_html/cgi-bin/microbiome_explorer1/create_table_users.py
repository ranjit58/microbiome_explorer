#!/usr/bin/python

import MySQLdb

# Open database connection
db = MySQLdb.connect("localhost","biotoolz_ranjit","ranjitiisc","biotoolz_microbiome" )

# prepare a cursor object using cursor() method
cursor = db.cursor()

# Create table as per requirement
sql = """CREATE TABLE users ( user_email VARCHAR(255) NOT NULL PRIMARY KEY, name VARCHAR(255), address VARCHAR(255), department VARCHAR(255),
user_notes VARCHAR(255) )"""

cursor.execute(sql)

# disconnect from server
db.close()

