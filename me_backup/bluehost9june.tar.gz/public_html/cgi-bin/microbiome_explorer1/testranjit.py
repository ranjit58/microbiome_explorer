#!/usr/bin/python
print "Content-type: text/html\r\n\r\n";

import cgi,cgitb
import MySQLdb

cgitb.enable()
html_code='''
<html>
<head>
<title>microbiome_explorer</title>
</head>
<body>
 I am ranjit
</body>
</html>
'''
print html_code
