#!/usr/bin/python
print "Content-type: text/plain\r\n\r\n";
print "Hello, world!";
#print "Content-Type: text/html"
#print "Hi Ranjit" 
