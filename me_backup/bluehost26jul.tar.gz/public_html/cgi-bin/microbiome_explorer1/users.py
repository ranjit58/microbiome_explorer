#!/usr/bin/python
print "Content-type:text/html\r\n\r\n"

import cgi,cgitb
import MySQLdb

cgitb.enable()
from datetime import datetime, date, time
# Open database connection
db = MySQLdb.connect("localhost","biotoolz_ranjit","ranjitiisc","biotoolz_microbiome" )
# prepare a cursor object using cursor() method
cursor = db.cursor()



html_code='''
<html>
<head><title>microbiome_explorer</title>


  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  

  <link href="/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/js/bootstrap.min.js"></script>
</head>
<body>

<!-- Navigation -->
    <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="runs.py">Microbiome Explorer</a>
            </div>
		<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
	 <ul class="nav navbar-nav navbar-right">
 	 <li ><a href="/~biotoolz/cgi-bin/microbiome_explorer1/samples.py">SAMPLES</a></li>
 	 <li ><a href="/~biotoolz/cgi-bin/microbiome_explorer1/runs.py">RUNS</a></li>
 	 <li ><a href="/~biotoolz/cgi-bin/microbiome_explorer1/users.py">USERS</a></li>
         <li ><a href="/~biotoolz/cgi-bin/microbiome_explorer1/projects.py">PROJECTS</a></li> 
	 </ul>
                   <!-- /.navbar-collapse -->
        </div>
                  <!-- /.container -->
    </nav> 
<br><br><br><br>


<div class="container">
    <div class="panel panel-primary">
    <div class="panel-body">
    <form class="form-inline" action="users.py" method="post">
       <div class="form-group">
           
                <input type="text" class="form-control" placeholder="Search by name" name="name">
      </div>
      &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                  <button type="submit" class="btn btn-success">Submit</button>
</form>
           
    </div>
</div>
</div>


'''
print html_code

# Create instance of FieldStorage 
form = cgi.FieldStorage() 

# Get data from fields

data_name = form.getvalue('name')

if "name" not in form:
      sql = "SELECT * FROM users ORDER BY user_email ASC"
else:
      sql = "SELECT * from users where name LIKE '%" + data_name + "%'"

cursor.execute(sql)

results = cursor.fetchall()


html_code='''
<div class="container">
<table class="table table-hover table-bordered" >
         <thead>

          <tr class="jumbotron"> 
            <th>user-email</th>
            <th>name</th>
            <th>address</th>
            <th>department</th>
            <th>user_notes</th>
         </tr>
        </thead>
'''
print html_code

for row in results:
      c1 = row[0]
      c2 = row[1]
      c3 = row[2]
      c4 = row[3]
      c5 = row[4]
      # Now print fetched result
      
      print '<tr><td>' + c1 + '</td><td>' + c2 + '</td><td>' + c3 + '</td><td>' + c4 + '</td><td>' + c5 + '</td></tr>'
      print "\n"     

html_code='''
</table>
</div>
</body>
</html>
'''
print html_code

db.close()
