#!/usr/bin/python
print "Content-type:text/html\r\n\r\n"

import cgi,cgitb
import MySQLdb

cgitb.enable()

# Open database connection
db = MySQLdb.connect("localhost","biotoolz_ranjit","ranjitiisc","biotoolz_microbiome" )
# prepare a cursor object using cursor() method
cursor = db.cursor()

# Prepare SQL query

sql2 = "SELECT DISTINCT user_email FROM samples"
sql3 = "SELECT DISTINCT user_project_name FROM samples"




cursor.execute(sql2)
results2 = cursor.fetchall()

cursor.execute(sql3)
results3 = cursor.fetchall()


html_code='''
<html>
<head><title>microbiome_explorer</title></head>

<body>
<title>microbiome_explorer</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  

  <link href="/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/js/bootstrap.min.js"></script>
</head>
<body>

<!-- Navigation -->
    <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="runs.py">Microbiome Explorer</a>
            </div>
		<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
	 <ul class="nav navbar-nav navbar-right">
 	 <li ><a href="/~biotoolz/cgi-bin/microbiome_explorer1/samples.py">SAMPLES</a></li>
 	 <li ><a href="/~biotoolz/cgi-bin/microbiome_explorer1/runs.py">RUNS</a></li>
 	 <li ><a href="/~biotoolz/cgi-bin/microbiome_explorer1/users.py">USERS</a></li>
         <li ><a href="/~biotoolz/cgi-bin/microbiome_explorer1/projects.py">PROJECTS</a></li> 
	 </ul>
                   <!-- /.navbar-collapse -->
        </div>
                  <!-- /.container -->
    </nav> 
<br><br><br><br>

<form action="projects.py" method="post">

<div class="container">
<div class="panel panel-primary">
    <div class="panel-body">  
                               

<select name="user_email">
'''
print html_code
for row in results2:
  #run_number = row[0]
  #fwd_data = row[1]
  #rev_data = row[2]
  #sample_name = row[3]
  #run_group = row[4]
  user_email = row[0]
  #user_project = row[6]
  # Now print fetched result
  #print "%s\t%s\t%s\t%s\t%s\t%s\t%s" % \
  #( run_number,fwd_data,rev_data,sample_name,run_group,user_email,user_project )
  #f.write("%s\t%s\t%s\t%s\t%s\t%s\t%s\n" % \
  #( run_number,fwd_data,rev_data,sample_name,run_group,user_email,user_project )
  print '<option value=',user_email,'>',user_email,'</option>'



  
html_code='''
<option value="all" selected>ALL</option>
</select> 
<select name="user_project_name">
'''
print html_code

for row in results3:
  #run_number = row[0]
  #fwd_data = row[1]
  #rev_data = row[2]
  #sample_name = row[3]
  #run_group = row[0]
  #user_email = row[5]
  user_project_name = row[0]
  # Now print fetched result
  #print "%s\t%s\t%s\t%s\t%s\t%s\t%s" % \
  #( run_number,fwd_data,rev_data,sample_name,run_group,user_email,user_project )
  #f.write("%s\t%s\t%s\t%s\t%s\t%s\t%s\n" % \
  #( run_number,fwd_data,rev_data,sample_name,run_group,user_email,user_project )
  print '<option value=',user_project_name,'>',user_project_name,'</option>'

  
html_code='''
<option value="all" selected>ALL</option>
</select>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<button type="submit" class="btn btn-success">Submit</button>

</div>
</div>
</div>
</form>


'''
print html_code


############################################################################


# Create instance of FieldStorage 
form = cgi.FieldStorage() 

# Get data from fields

data_user_email = form.getvalue('user_email')
data_user_project_name = form.getvalue('user_project_name')



#print "Request:"
#print "sample_name:",data_sample_name,"   "
#print "Run:",data_run_id," "
#print "Email:",data_user_email,"  "
#print "Project:",data_user_project_name,"  "


if "user_email" not in form:
      sql4 = "SELECT * FROM projects"

else:


  if data_user_email=="all" and data_user_project_name=="all":
      sql4 = "Select * FROM projects"
    
  
  elif data_user_email=="all":
      sql4 = "Select * FROM projects where user_project_name = '" + data_user_project_name + "'"
  elif data_user_project_name=="all":
      sql4 = "SELECT * FROM projects where user_email = '" + data_user_email + "'"

  else:
      sql4 = "SELECT * FROM projects WHERE user_email = '" + data_user_email + "' AND user_project_name = '" + data_user_project_name + "'"


cursor.execute(sql4)

results4 = cursor.fetchall()


html_code='''
<div class="container">
<table class="table table-hover table-bordered" >
         <thead>

          <tr class="jumbotron"> 
            <th>user_email</th>
            <th>user_project_name</th>
            <th>project_details</th>
            <th>sample_details</th>
            <th>project_share</th>
          </tr>
        </thead>
'''
print html_code

for row in results4:
      run_id = row[0]
      fwd_sample = row[1]
      rev_sample = row[2]
      sample_name = row[3]
      run_group = row[4]
      # Now print fetched result
      print '<tr><td>' + run_id + '</td><td>' + fwd_sample + '</td><td>' + rev_sample + '</td><td>' + sample_name + '</td><td>' + run_group + '</td></tr>'
      print "\n"     

html_code='''
</table>
</div>
</body>
</html>
'''
print html_code

db.close()
