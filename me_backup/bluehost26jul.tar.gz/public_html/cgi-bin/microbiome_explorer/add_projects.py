#!/usr/bin/python
print "Content-type:text/html\r\n\r\n"
import cgi,cgitb
cgitb.enable()
import MySQLdb
import module
import os, sys
# Open database connection
db = MySQLdb.connect("localhost","biotoolz_ranjit","ranjitiisc","biotoolz_microbiome_explorer" )
# prepare a cursor object using cursor() method
cursor = db.cursor()

sql1 = "SELECT DISTINCT user_email FROM users"
cursor.execute(sql1)
results1 = cursor.fetchall()





html_codes='''

<html>

<head><title>microbiome_explorer</title>

<title>microbiome_explorer</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  

  <link href="/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/js/bootstrap.min.js"></script>
</head>
<body>

'''
print html_codes
module.print_func()
html_code='''
<div class="container">

<div class="panel panel-default">
<div class="panel-heading">    
<b>Add Projects</b>
</div>
      <div class="panel-body">
 <form class="form-inline" action="/~biotoolz/cgi-bin/microbiome_explorer/save_new_project.py" method="post">
Project Name&nbsp;<sup><span class="glyphicon glyphicon-asterisk" style="color:red;font-size: 8px"></span></sup>&nbsp;:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" class="form-control" name="run_group">

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Email&nbsp;<sup><span class="glyphicon glyphicon-asterisk" style="color:red;font-size: 8px"></span></sup>&nbsp;:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input list="user_email" class="form-control" name="user_email">
<datalist id="user_email">
'''
print html_code

for row in results1:
 
  user_email = row[0]
  print '<option value=',user_email,'>',user_email,'</option>'

html_codes='''

<option selected hidden value=""></option>
</datalist> 
'''
print html_codes




html_codes='''

      &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
      <br><br>
      Title:    &nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;<input type="text" class="form-control" name="title" size="69" Value="">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br><br>
      Notes: &nbsp;&nbsp;&nbsp;&nbsp&nbsp;&nbsp;<textarea class="form-control" name="notes" rows="3" cols="71" value=""></textarea>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br><br>
      Links: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<textarea class="form-control" rows="3" cols="71" name="links" value=""></textarea>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br><br>
     
      

	    <button type="submit" class="btn btn-success">Submit</button>
	    </div>
        
      </form> 
      </div>
  
      
    
</div>
</div>

    
  
  
   
</body>
</html>
'''
print html_codes
