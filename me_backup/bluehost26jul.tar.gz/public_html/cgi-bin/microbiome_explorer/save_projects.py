#!/usr/bin/python
print "Content-type:text/html\r\n\r\n"
import cgi,cgitb
cgitb.enable()
import MySQLdb
import os, sys
import module
# Open database connection
db = MySQLdb.connect("localhost","biotoolz_ranjit","ranjitiisc","biotoolz_microbiome_explorer" )
# prepare a cursor object using cursor() method
cursor = db.cursor()

form = cgi.FieldStorage()


data_run_group = form.getvalue('run_group')
data_user_email = form.getvalue('user_email')
data_title = form.getvalue('title')
data_notes = form.getvalue('notes')
data_links = form.getvalue('links')

if data_title == None:
   data_title = ""
if data_notes == None:
   data_notes = ""
if data_links == None:
   data_links = ""
print data_run_group
print data_user_email

# Test if the file was uploaded
if "user_email" in form and "run_group" in form:
#if "user_email" in form and "run_group" in form:
   sql = "DELETE FROM projects WHERE run_group = '" + data_run_group + "';"
   try:
     # Execute the SQL command
     cursor.execute(sql)
     #  Commit your changes in the database
     db.commit()
     #message = '<div class="container"><h4>Project added sucessfully</h4></div>'

   except :
     #message = '<div class="container"><h4>Error: Project not deleted/exits added </h4></div>'
     # Rollback in case there is any error
     db.rollback()

   sql = "INSERT INTO projects (run_group,user_email,title,notes,links) VALUES('" + data_run_group + "', '" + data_user_email + "', '" + data_title + "', '" + data_notes + "', '" + data_links + "');"
   try:
     # Execute the SQL command
     cursor.execute(sql)
     #  Commit your changes in the database
     db.commit()
     message = '<div class="container"><h4>Project added/edited sucessfully</h4></div>'

   except MySQLdb.IntegrityError, e:
     message = '<div class="container"><h4>Error: Project not added/edited (maybe a project with same name exists)</h4></div>'
     # Rollback in case there is any error
     db.rollback()


    
else:
   message = '<div class="container"><h4>Not Sufficient inputs provided!<br><br> Please provide Project name and Email address.</h4></div>'  
   
   
   
html_code='''
Content-Type: text/html\n
<html>
<head>
<title>microbiome_explorer</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  

  <link href="/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/js/bootstrap.min.js"></script>
</head>
<body>
'''
print html_code
module.print_func()
print message
html_code='''

</body>
</html>
'''
print html_code
cursor.close()
db.commit()
 
# disconnect from server
db.close()
